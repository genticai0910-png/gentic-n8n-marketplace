# Gumroad Listing — Ecommerce Store Content Pack (Starter)

## Title
Ecommerce Store Content Starter Pack

## Price
$12

## Tagline
[Add outcome statement]

## Description
[Add full description]

## Tags
content, ecommerce, store, tiktok, instagram, social media
