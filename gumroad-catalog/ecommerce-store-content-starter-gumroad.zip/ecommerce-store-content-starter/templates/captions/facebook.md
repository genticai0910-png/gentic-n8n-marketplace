# Facebook Caption Templates — Ecommerce Store

## Template #1 — [Type]
```
[Caption template with {placeholders}]
```

[TODO: Add 1 templates]
