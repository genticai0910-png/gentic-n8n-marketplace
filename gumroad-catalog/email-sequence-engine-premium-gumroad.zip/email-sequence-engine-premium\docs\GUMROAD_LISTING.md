# Gumroad Listing — Email Sequence Engine

## Title
Email Sequence Engine — [Add Key Benefit]

## Price
$37

## Tagline
[Add one-sentence outcome statement]

## Description
[Add full description following copywriting patterns]

## Tags
n8n, automation, workflow, email, sequence, engine
