# Linkedin Caption Templates — Fitness Coach

## Template #1 — [Type]
```
[Caption template with {placeholders}]
```

[TODO: Add 5 templates]
