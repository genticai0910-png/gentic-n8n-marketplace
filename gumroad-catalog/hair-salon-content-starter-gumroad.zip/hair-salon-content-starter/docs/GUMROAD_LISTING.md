# Gumroad Listing — Hair Salon Content Pack (Starter)

## Title
Hair Salon Content Starter Pack

## Price
$12

## Tagline
[Add outcome statement]

## Description
[Add full description]

## Tags
content, hair, salon, tiktok, instagram, social media
