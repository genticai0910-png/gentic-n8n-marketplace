# Posting Calendar — Lawyer

## Optimal Posting Times

| Platform | Best Times | Best Days |
|----------|------------|-----------|
| TikTok | 7am, 12pm, 7pm | Tue, Thu, Sat |
| Instagram | 8am, 12pm, 5pm | Mon, Wed, Fri |
[TODO: Complete table]

## Weekly Content Rotation
[TODO: Add rotation schedule]
