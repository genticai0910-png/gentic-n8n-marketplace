# Facebook Caption Templates — Lawyer

## Template #1 — [Type]
```
[Caption template with {placeholders}]
```

[TODO: Add 5 templates]
