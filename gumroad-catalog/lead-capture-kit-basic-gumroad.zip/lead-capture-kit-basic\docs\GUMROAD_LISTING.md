# Gumroad Listing — Lead Capture Kit

## Title
Lead Capture Kit — [Add Key Benefit]

## Price
$12

## Tagline
[Add one-sentence outcome statement]

## Description
[Add full description following copywriting patterns]

## Tags
n8n, automation, workflow, lead, capture, kit
