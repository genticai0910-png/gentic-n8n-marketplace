# Done-For-You Avatar Scripts — Mortgage Broker

## Script #1 — [Title]
**Duration**: 45 seconds
**Pillar**: [Category]

```
[HOOK - 0:00-0:03]
[Opening line]

[BODY - 0:03-0:35]
[Main content]

[CTA - 0:35-0:45]
[Call to action]
```

[TODO: Add 30 total scripts]
