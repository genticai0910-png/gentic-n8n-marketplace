# Instagram Caption Templates — Real Estate Agent

## Template #1 — [Type]
```
[Caption template with {placeholders}]
```

[TODO: Add 1 templates]
