# Tiktok Caption Templates — Restaurant Owner

## Template #1 — [Type]
```
[Caption template with {placeholders}]
```

[TODO: Add 5 templates]
