# Viral Hooks Library — Therapist

## Starter Hooks (10)

### Hook #1 — [Category]
`"[Hook template with [BRACKETS]]"`
**Why it works**: [Explanation]

[TODO: Add 50 total hooks]
